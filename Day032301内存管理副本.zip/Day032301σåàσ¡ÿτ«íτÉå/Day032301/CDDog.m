//
//  CDDog.m
//  Day032301
//
//  Created by LUOHao on 16/3/23.
//  Copyright (c) 2016年 mobiletrain. All rights reserved.
//

#import "CDDog.h"

@implementation CDDog

- (void) dealloc {
    _nickname = nil;
    // [_nickname release];
}

@end
