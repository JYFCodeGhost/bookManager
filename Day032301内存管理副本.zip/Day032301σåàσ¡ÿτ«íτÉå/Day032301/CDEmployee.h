//
//  CDEmployee.h
//  Day032301
//
//  Created by LUOHao on 16/3/23.
//  Copyright (c) 2016年 mobiletrain. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CDDepartment;

@interface CDEmployee : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, weak) CDDepartment *dept;

- (void) foo;

@end
