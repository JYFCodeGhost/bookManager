//
//  CDDog.h
//  Day032301
//
//  Created by LUOHao on 16/3/23.
//  Copyright (c) 2016年 mobiletrain. All rights reserved.
//

#import <Foundation/Foundation.h>

// 坚持使用ARC 不要装逼用MRC
// 如果非要用MRC 记住: 谁创建谁释放 谁加1谁减1
// 自动释放池是可以嵌套的
// ARC模式下要正确的使用内存最关键的就是书写正确的
// 和内存管理相关的属性修饰符
// strong - 对象指针一般都用strong表示对引用计数+1 默认值
// weak -
//  1. 出现循环引用的时候有一方必须使用weak(破除循环引用)
//  2. 一个对象的生命周期不由你自己的代码管理
//  3. 属性是一个协议指针
// copy -
//  1. 确保NSString、NSArray、NSDictionary、NSData等不可变类型的指针确确实实的指向一个不可变对象
//  2. 如果属性是一个Block类型的变量必须用copy
// assign -
//  1. 非对象指针类型(整型、字符型、实型、布尔型、枚举、结构体、联合体)都用assign
//  2. 如果属性是对象指针 assign相当于weak
// 不要在C的结构体中使用对象的指针 因为无法进行内存管理

@interface CDDog : NSObject

@property (nonatomic, copy) NSString *nickname;

@end
