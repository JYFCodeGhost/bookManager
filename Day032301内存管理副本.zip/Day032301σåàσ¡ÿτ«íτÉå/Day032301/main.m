//
//  main.m
//  Day032301
//
//  Created by LUOHao on 16/3/23.
//  Copyright (c) 2016年 mobiletrain. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDEmployee.h"
#import "CDDepartment.h"

int main(int argc, const char * argv[]) {
    while(1) {
        @autoreleasepool {
            CDDepartment *dept = [[CDDepartment alloc] init];
            dept.no = 10;
            dept.name = @"研发部";
            CDEmployee *emp = [[CDEmployee alloc] init];
            emp.name = @"骆昊";
            emp.dept = dept;
            dept.manager = emp;
        }
        usleep(100);
    }
    return 0;
}
